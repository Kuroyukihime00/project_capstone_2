@extends('layouts.index')

@section('content')
<div class="container">
  <div class="page-inner">
    <h4>Register</h4>
    <p>Konten akan ditambahkan di sini.</p>
  </div>
</div>
@endsection
