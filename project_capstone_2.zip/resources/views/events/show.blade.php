@extends('layouts.index')

@section('content')
<div class="container">
  <div class="page-inner">
    <h4>Show</h4>
    <p>Konten akan ditambahkan di sini.</p>
  </div>
</div>
@endsection
