@extends('layouts.index')

@section('content')
<div class="container">
  <div class="page-inner">
    <div class="page-header">
      <h4 class="page-title">Edit Certificates</h4>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <p>Konten akan ditambahkan di sini.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
