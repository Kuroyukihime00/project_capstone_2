@extends('layouts.index')

@section('content')
<div class="container">
  <h4>Registrasi untuk Event: {{ $event->name }}</h4>

  @if ($existing)
    <div class="alert alert-info">Kamu sudah terdaftar. Ini QR code kamu:</div>
    <img src="{{ $qrData }}" alt="QR Code" class="img-thumbnail">
  @else
    <form method="POST" action="{{ route('member.events.register', $event->id) }}">
      @csrf

      <div class="mb-3">
        <label for="session_id" class="form-label">Pilih Sesi</label>
        <select name="session_id" id="session_id" class="form-select" required>
          <option value="">-- Pilih Sesi --</option>
          @foreach($event->sessions as $session)
            <option value="{{ $session->id }}">
              {{ $session->title }} ({{ $session->tanggal }} {{ $session->waktu }})
            </option>
          @endforeach
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Daftar</button>
    </form>
  @endif
</div>
@endsection
