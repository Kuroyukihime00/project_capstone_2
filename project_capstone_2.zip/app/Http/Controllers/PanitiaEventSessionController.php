<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\EventSession;
use Illuminate\Http\Request;

class PanitiaEventSessionController extends Controller
{
    public function create(Event $event)
    {
        return view('panitia.sessions.create', compact('event'));
    }

    public function store(Request $request, Event $event)
    {
        $request->validate([
            'title' => 'required|string|max:100',
            'tanggal' => 'required|date',
            'waktu' => 'required',
        ]);

        EventSession::create([
            'event_id' => $event->id,
            'title' => $request->title,
            'tanggal' => $request->tanggal,
            'waktu' => $request->waktu,
        ]);

        return redirect()->route('panitia.dashboard')->with('success', 'Sesi berhasil ditambahkan.');
    }
}
