<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <div class="page-header">
      <h4 class="page-title">Dashboard Admin</h4>
    </div>

    <div class="row">

      
      <div class="col-md-4">
        <div class="card card-stats card-round">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-icon">
                <div class="icon-big text-center icon-info">
                  <i class="fa fa-users"></i>
                </div>
              </div>
              <div class="col col-stats">
                <div class="numbers">
                  <p class="card-category">Total Pengguna</p>
                  <h4 class="card-title"><?php echo e(\App\Models\User::count()); ?></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div class="col-md-4">
        <div class="card card-stats card-round">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-icon">
                <div class="icon-big text-center icon-primary">
                  <i class="fa fa-calendar-alt"></i>
                </div>
              </div>
              <div class="col col-stats">
                <div class="numbers">
                  <p class="card-category">Total Event</p>
                  <h4 class="card-title"><?php echo e(\App\Models\Event::count()); ?></h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div class="col-md-4">
        <div class="card card-stats card-round">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-icon">
                <div class="icon-big text-center icon-success">
                  <i class="fa fa-user-tie"></i>
                </div>
              </div>
              <div class="col col-stats">
                <div class="numbers">
                  <p class="card-category">Panitia Terdaftar</p>
                  <h4 class="card-title">
                    <?php echo e(\App\Models\User::whereHas('role', fn($q) => $q->where('name', 'panitia'))->count()); ?>

                  </h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>