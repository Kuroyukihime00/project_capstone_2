<?php $__env->startSection('content'); ?>
<div class="container">
  <h4>Tambah Event</h4>
  <form method="POST" action="<?php echo e(route('panitia.events.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label>Nama Event</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Tanggal</label>
      <input type="date" name="tanggal" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Waktu</label>
      <input type="time" name="waktu" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Lokasi</label>
      <input type="text" name="lokasi" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Narasumber</label>
      <input type="text" name="narasumber" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Poster (nama file saja)</label>
      <input type="text" name="poster" class="form-control">
    </div>
    <div class="mb-3">
      <label>Biaya Registrasi</label>
      <input type="number" name="biaya" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Max Peserta</label>
      <input type="number" name="max_peserta" class="form-control" required>
    </div>
    <button class="btn btn-success">Simpan</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/events/create.blade.php ENDPATH**/ ?>