<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'SuratApp'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- KaiAdmin Styles -->
    <link href="<?php echo e(asset('kaiadmin/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('kaiadmin/assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('kaiadmin/assets/css/icons.css')); ?>" rel="stylesheet">
</head>
<body>

    <!-- Sidebar -->
    <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Header -->
    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <main class="main-content p-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- KaiAdmin Scripts -->
    <script src="<?php echo e(asset('kaiadmin/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('kaiadmin/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('kaiadmin/assets/js/script.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/layouts/app.blade.php ENDPATH**/ ?>