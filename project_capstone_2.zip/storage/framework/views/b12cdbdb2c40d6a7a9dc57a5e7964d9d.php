<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <h4>Selamat datang, <?php echo e(auth()->user()->name); ?></h4>
    <p>Silakan akses menu Event, Pembayaran, atau Sertifikat dari sidebar.</p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/dashboard/member.blade.php ENDPATH**/ ?>