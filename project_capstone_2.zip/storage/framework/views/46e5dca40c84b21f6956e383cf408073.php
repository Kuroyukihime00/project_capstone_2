<header class="bg-light p-3 mb-4" style="margin-left: 220px;">
    <div class="container-fluid d-flex justify-content-between align-items-center">
        <div>
            <?php if(auth()->guard()->check()): ?>
                <h5 class="mb-0">Selamat datang, <?php echo e(Auth::user()->name); ?></h5>
            <?php else: ?>
                <h5 class="mb-0">Selamat datang, Tamu</h5>
            <?php endif; ?>
        </div>

        <div class="d-flex align-items-center gap-3">
            <span class="text-muted"><?php echo e(now()->format('d M Y')); ?></span>

            <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="mb-0">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-outline-danger">
                    <i class="fa fa-sign-out-alt"></i> Logout
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/layouts/header.blade.php ENDPATH**/ ?>