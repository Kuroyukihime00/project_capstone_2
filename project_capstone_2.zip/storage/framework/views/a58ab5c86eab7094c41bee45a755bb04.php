

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h4>Daftar Sesi Semua Event</h4>
    <a href="<?php echo e(route('admin.sessions.create')); ?>" class="btn btn-primary mb-3">
        <i class="fa fa-plus"></i> Tambah Sesi
    </a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Event</th>
                <th>Judul Sesi</th>
                <th>Tanggal</th>
                <th>Waktu</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($session->event->name); ?></td>
                <td><?php echo e($session->title); ?></td>
                <td><?php echo e($session->tanggal); ?></td>
                <td><?php echo e($session->waktu); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/admin/sessions/index.blade.php ENDPATH**/ ?>