

<?php $__env->startSection('content'); ?>
<div class="container">
  <h4>Registrasi untuk Event: <?php echo e($event->name); ?></h4>

  <?php if($existing): ?>
    <div class="alert alert-info">Kamu sudah terdaftar. Ini QR code kamu:</div>
    <img src="<?php echo e($qrData); ?>" alt="QR Code" class="img-thumbnail">
  <?php else: ?>
    <form method="POST" action="<?php echo e(route('member.events.register', $event->id)); ?>">
      <?php echo csrf_field(); ?>

      <div class="mb-3">
        <label for="session_id" class="form-label">Pilih Sesi</label>
        <select name="session_id" id="session_id" class="form-select" required>
          <option value="">-- Pilih Sesi --</option>
          <?php $__currentLoopData = $event->sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($session->id); ?>">
              <?php echo e($session->title); ?> (<?php echo e($session->tanggal); ?> <?php echo e($session->waktu); ?>)
            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Daftar</button>
    </form>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/member/events/register.blade.php ENDPATH**/ ?>