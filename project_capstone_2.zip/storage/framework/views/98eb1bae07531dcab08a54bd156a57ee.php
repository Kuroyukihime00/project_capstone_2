<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <h4>Dashboard Panitia</h4>

    <?php
      use App\Models\Event;
      use App\Models\EventRegistration;
      use App\Models\Attendance;

      $events = Event::with('sessions')->latest()->get();
    ?>

    <div class="row">
      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $registrations = EventRegistration::with('session')
              ->where('event_id', $event->id)->get();

          $terdaftar = $registrations->count();
          $hadir = Attendance::whereIn('event_registration_id', $registrations->pluck('id'))->count();
        ?>

        <div class="col-md-6 mb-4">
          <div class="card shadow-sm">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($event->name); ?></h5>
              <p class="mb-1"><strong>Tanggal:</strong> <?php echo e($event->tanggal); ?></p>
              <p class="mb-1"><strong>Peserta Terdaftar:</strong> <?php echo e($terdaftar); ?></p>
              <p class="mb-2"><strong>Peserta Hadir:</strong> <?php echo e($hadir); ?></p>

              <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item">
                    <?php echo e($reg->user->name); ?> -
                    Sesi: <?php echo e($reg->session->title ?? 'Tidak memilih'); ?> <br>
                    <a href="<?php echo e(route('panitia.scan', $reg->id)); ?>" class="btn btn-sm btn-success mt-1">
                      Scan QR
                    </a>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/dashboard/panitia.blade.php ENDPATH**/ ?>