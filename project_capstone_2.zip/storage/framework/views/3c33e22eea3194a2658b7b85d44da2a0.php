

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <h4>Sertifikat Saya</h4>

    <?php if($certificates->isEmpty()): ?>
      <div class="alert alert-warning mt-3">
        Anda belum memiliki sertifikat.
      </div>
    <?php else: ?>
    <div class="row mt-3">
      <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mb-4">
        <div class="card shadow-sm h-100">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($cert->registration->event->name); ?></h5>
            <p class="card-text">
              Tanggal: <?php echo e($cert->registration->event->tanggal); ?><br>
              Sesi: <?php echo e($cert->registration->session->title ?? '-'); ?>

            </p>
            <a href="<?php echo e(route('member.certificates.download', $cert->registration_id)); ?>" class="btn btn-sm btn-primary">
              <i class="fa fa-download me-1"></i> Unduh Sertifikat
            </a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/member/certificates/index.blade.php ENDPATH**/ ?>