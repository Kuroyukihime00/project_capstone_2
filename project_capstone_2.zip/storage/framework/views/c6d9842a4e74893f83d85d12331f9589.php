

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <h4>Daftar Event Terbuka</h4>
    <div class="row">
      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6 mb-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title"><?php echo e($event->name); ?></h5>
            <p><strong>Tanggal:</strong> <?php echo e($event->tanggal); ?></p>
            <p><strong>Waktu:</strong> <?php echo e($event->waktu); ?></p>
            <p><strong>Lokasi:</strong> <?php echo e($event->lokasi); ?></p>
            <p><strong>Biaya:</strong> Rp<?php echo e(number_format($event->biaya, 0, ',', '.')); ?></p>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login untuk Daftar</a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/guest/events.blade.php ENDPATH**/ ?>