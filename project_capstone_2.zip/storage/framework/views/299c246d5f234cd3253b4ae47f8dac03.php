<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <h4>Upload Bukti Pembayaran</h4>
    <form method="POST" action="<?php echo e(route('member.payments.store', $registration->id)); ?>" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="proof">Bukti Pembayaran</label>
        <input type="file" name="proof" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-success mt-2">Upload</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/memberpayment/create.blade.php ENDPATH**/ ?>