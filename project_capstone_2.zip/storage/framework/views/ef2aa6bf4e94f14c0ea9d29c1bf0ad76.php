<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <h4>Daftar Event</h4>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Nama</th>
          <th>Tanggal</th>
          <th>Lokasi</th>
          <th>Biaya</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($event->name); ?></td>
          <td><?php echo e($event->tanggal); ?></td>
          <td><?php echo e($event->lokasi); ?></td>
          <td>Rp <?php echo e(number_format($event->biaya)); ?></td>
          <td>
            <a href="<?php echo e(route('member.events.register', $event->id)); ?>" class="btn btn-sm btn-primary">Daftar</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/events/index.blade.php ENDPATH**/ ?>