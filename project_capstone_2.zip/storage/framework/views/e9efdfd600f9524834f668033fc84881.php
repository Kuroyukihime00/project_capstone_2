<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="page-inner">
    <h4>Dashboard Keuangan</h4>

    <?php
      use App\Models\EventRegistration;
      $pending = EventRegistration::with('event', 'user')->where('status', 'pending')->get();
    ?>

    <h6 class="mt-3">Verifikasi Pembayaran Pending</h6>
    <table class="table table-bordered mt-2">
      <thead>
        <tr>
          <th>Nama</th>
          <th>Event</th>
          <th>Tindakan</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($reg->user->name); ?></td>
          <td><?php echo e($reg->event->name); ?></td>
          <td>
            <form method="POST" action="<?php echo e(route('keuangan.registrations.verify', $reg->id)); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-success">Verifikasi</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/dashboard/keuangan.blade.php ENDPATH**/ ?>