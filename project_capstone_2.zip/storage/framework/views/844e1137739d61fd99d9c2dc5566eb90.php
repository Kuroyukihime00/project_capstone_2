

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <h4>Daftar Registrasi untuk Scan QR</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Peserta</th>
                    <th>Event</th>
                    <th>Sesi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($reg->user->name); ?></td>
                    <td><?php echo e($reg->event->name); ?></td>
                    <td><?php echo e($reg->session->title ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('panitia.scan', $reg->id)); ?>" class="btn btn-primary btn-sm">
                            Scan Hadir
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\EGI\awp\project_capstone_2\resources\views/panitia/scan/index.blade.php ENDPATH**/ ?>